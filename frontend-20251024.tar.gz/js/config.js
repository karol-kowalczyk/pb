// arrays - products
// Alphabetisch sortierte profile_descriptions mit entsprechend sortierten productIDs
const profile_descriptions = [
  "ALU - Abdichtkappe",
  "ALU-Abdichtungsprofil",
  "ALU - Abschlussprofil",
  "ALU - Abschlussprofil Alupaneel",
  "ALU - Blende",
  "ALU - Blende_CP",
  "ALU - Dachrinne",
  "ALU - Dachrinne Kombi",
  "ALU - Dachrinne XL",
  "ALU - Dachrinne_CP",
  "ALU - Dachrinne_CP Deckel",
  "ALU - Deckel Fensterrahmen Profil",
  "ALU - Aludeckel Sparren",
  "ALU - Fensterrahmen Klickleiste",
  "ALU - Fensterrahmen L-Profil",
  "ALU - Fensterrahmen T-Profil",
  "ALU - Flache Führungsschiene unten - 3GL",
  "ALU - Flache Führungsschiene unten - 4GL",
  "ALU - Flache Führungsschiene unten - 5GL",
  "ALU - Führungsprofil für Glasmodul",
  "ALU - Führungschiene oben - 3GL",
  "ALU - Führungschiene oben - 4GL",
  "ALU - Führungschiene oben - 5GL",
  "ALU - Glaskoppelleiste oben",
  "ALU - Glaskoppelleiste unten",
  "ALU - L 120x20",
  "ALU - L 155x30",
  "ALU - L 52x20",
  "ALU - L-profil_CP (Oben)",
  "ALU - L-profil_CP (Unten)",
  "ALU - Panelprofil",
  "ALU - Panelprofil_SLIM",
  "ALU - Rechteckprofil 50 x 50",
  "ALU - Rechteckprofil 70 x 50",
  "ALU - Rechteckprofil 90 x 50",
  "ALU - Rechteckprofil 150 x 50",
  "ALU - Schwellenprofil",
  "ALU - Sparren",
  "ALU - Sparren 160 x 60",
  "ALU - Sparren 279 x 60",
  "ALU - Sparren mit LED Kanal",
  "ALU - Statikträger",
  "ALU - Statikträger-Deckel",
  "ALU - Stutze 110",
  "ALU - Stutze 160",
  "ALU - Stütze 160 x 160",
  "ALU - Wandanschlussprofil",
  "ALU - Wandprofil neu",
  "ALU - Wandprofil Kombi",
  "ALU - Wandprofil_CP",
  "ALU - Wetterschutzwinkel",
  "LAS - Befestigung für Sparren 279 x 60",
  "LAS - CP_Glas-Stopper",
  "LAS - Deckel Führungschiene oben - 3GL",
  "LAS - Deckel Führungschiene oben - 4GL",
  "LAS - Deckel Führungschiene oben - 5GL",
  "LAS - Design Blende",
  "LAS - Führungsprofil Deckel",
  "LAS - Fußverriegelung",
  "LAS - Heizungslasche",
  "LAS - Schwerlastwinkel",
  "LAS - Seitendeckel Dachrinne Kombi",
  "LAS - Seitendeckel Dachrinne XL",
  "LAS - Seitendeckel Profil 50x50",
  "LAS - Seitendeckel Profil 110x110",
  "LAS - Seitendeckel Profil 110x160",
  "LAS - Seitendeckel Rinne",
  "LAS - Seitendeckel Rinne-Statikträger",
  "LAS - Seitendeckel Sparren",
  "LAS - Seitendeckel Statikträger",
  "LAS - Seitendeckel Wandprofil Kombi",
  "LAS - Seitendeckel Wandprofil neu",
  "LAS - Seitendeckel Wetterschutzwinkel",
  "LAS - Stop-Platte",
  "LAS - Statikträger-Wandprofil Deckel",
  "LAS - Wandprofil_CP - Deckel",
  "LAS - Dachrinne_CP - Deckel",
  "SCHL - Abdeckung Teil 1 (hinten)",
  "SCHL - Abdeckung Teil 2 (ohne Schloss)",
  "SCHL - Abdeckung Teil 2 (vorne)_L",
  "SCHL - Abdeckung Teil 2 (vorne)_P",
  "SCHL - Griff (mit Schloss)",
  "SCHL - Griff (ohne Schloss)",
  "SCHL - Standardgriff groß",
  "SCHL - Standardgriff klein"
];

const productIDs = [
  'ALU-ABDKA',
  'ALU-ABDP',
  'ALU-ABSCHL',
  'ALU-ABS-PAN',
  'ALU-BLE',
  'ALU-BLE-CP',
  'ALU-RINN',
  'ALU-RINN-KOM',
  'ALU-RINN-XL',
  'ALU-RINN-CP',
  'ALU-RINN-DEC-CP',
  'ALU-FEN-DEC',
  'ALU-DEC',
  'ALU-FEN-KLI',
  'ALU-FEN-L',
  'ALU-FEN-T',
  'ALU-3UFüH',
  'ALU-4UFüH',
  'ALU-5UFüH',
  'ALU-FüGH',
  'ALU-3OFüH',
  'ALU-4OFüH',
  'ALU-5OFüH',
  'ALU-GLAKO-O',
  'ALU-GLAKO-U',
  'ALU-L120',
  'ALU-L155',
  'ALU-L52',
  'ALU-LPRO-CP',
  'ALU-LPRU-CP',
  'ALU-PANEL',
  'ALU-PANEL-SLIM',
  'ALU-50x50',
  'ALU-70x50',
  'ALU-90x50',
  'ALU-150x50',
  'ALU-SCHWP',
  'ALU-SPAR',
  'ALU-SPAR-160',
  'ALU-SPAR-279',
  'ALU-SPAR-LED',
  'ALU-STAT',
  'ALU-STAT-DEC',
  'ALU-STU-110',
  'ALU-STU-160',
  'ALU-STUCP-160',
  'ALU-SEIP',
  'ALU-WAN-N',
  'ALU-WAN-KOM',
  'ALU-WANP-CP',
  'ALU-WANDANSCHL',
  'LAS-BSPAR-279',
  'LAS-STOP-CP',
  'LAS-ABFüS3',
  'LAS-ABFüS4',
  'LAS-ABFüS5',
  'LAS-DES-BLE',
  'LAS-ABFüG',
  'LAS-FUß',
  'LAS-HEIZ',
  'LAS-STU-WI',
  'LAS-RN-KO',
  'LAS-RN-XL',
  'LAS-STU-50',
  'LAS-STU-110',
  'LAS-STU-160',
  'LAS-RINN',
  'LAS-ST-RN',
  'LAS-SPAR-DEC',
  'LAS-STAT',
  'LAS-WN-KO',
  'LAS-WAN-N',
  'LAS-ST-WN',
  'LAS-WETT',
  'LAS-STOP-P',
  'LAS-ST-WN',
  'LAS-WANCP-DEC',
  'LAS-RINN-DEC-CP',
  'SCHL-ABT1H',
  'SCHL-ABT2OS',
  'SCHL-ABT2VL',
  'SCHL-ABT2VP',
  'SCHL-GRSCH',
  'SCHL-GROSCH',
  'SCHL-BGLM',
  'SCHL-BGRI'
];

const predefinedColors = [
  "Anthrazit (Tiger 29/80077) DB 703 Eisenglimmerglau",
  "Anthrazit (Tiger 29/71289) RAL 7016",
  "Braun (Tiger 029/60740) Sepia Brown 'Marrone'",
  "Dunkelgrau (Tiger 029/50704) Fire Green - RAL 6009",
  "Anthrazit (Tiger 29/71289) RAL 7016 FS",
  "Graualuminium (Tiger 29/90147) RAL 9007",
  "Hellgrau (Tiger 029/90146) RAL 9006",
  "Reinweiß (Tiger 29/10797) RAL 9010",
  "Silber (Tiger 029/70786) Sparkling Iron Effect",
  "Verkehrsweiß Glatt (Tiger 29/10002) RAL 9016",
  "Verkehrsweiß strukturiert (Tiger 29/10246) RAL 9016"
];

// CONST - IDs HTML
const searchInput = document.getElementById("profile-search");
const resultsContainer = document.getElementById("profile-search-results");
const colorSelect = document.getElementById('color-select');
const colorCustomInput = document.getElementById('color-custom');
const addColorBtn = document.getElementById('add-color-btn');

async function loadDataFromServer(key) {
  const response = await fetch(`${BASE_URL}/load/${key}/`);
  if (!response.ok) {
    throw new Error('Daten nicht gefunden');
  }
  return await response.json();
}

// DOMContentLoaded Event für Laden der Daten bei ?key=...
window.addEventListener('DOMContentLoaded', async () => {
  const params = new URLSearchParams(window.location.search);
  const key = params.get("key");
  console.log("Geladener Key aus URL:", key);

  if (!key) {
    console.warn("Kein Key in URL");
    return;
  }

  let data;
  try {
    data = await loadDataFromServer(key);
    console.log("Geladene Daten vom Backend:", data);
  } catch (e) {
    console.warn("Keine gespeicherten Daten gefunden für:", key);
    return;
  }

  // Formularfelder befüllen
  document.getElementById("commission-input").value = data.kommission || "";
  document.getElementById("company-select").value = data.empfaenger || "";
  document.getElementById("color-select").value = data.farbe || "";

  // Farb-Dropdown ggf. anpassen
  const colorSelect = document.getElementById("color-select");
  if (data.farbe && !Array.from(colorSelect.options).some(opt => opt.value === data.farbe)) {
    const customOption = document.createElement("option");
    customOption.value = data.farbe;
    customOption.textContent = data.farbe;
    colorSelect.appendChild(customOption);
    colorSelect.value = data.farbe;
  }

  // Positionen einfügen
  if (Array.isArray(data.positionen)) {
    data.positionen.forEach(pos => {
      addProfileRow(); // Funktion von dir, neue Zeile erzeugen
      const lastRow = document.querySelectorAll(".profile-row");
      const row = lastRow[lastRow.length - 1];

      row.querySelector(".profile-select").value = pos.produktnummer;
      row.querySelector(".profile-anzahl").value = pos.anzahl;
      const unitSelect = row.querySelector(".profile-unit");
      if (unitSelect) {
        unitSelect.value = pos.einheit === "Stck" ? "stck" : pos.einheit;
        updateLengthInputMode(row);
        updateQuantityInputMode(row);
      }
      const lengthInput = row.querySelector(".profile-laenge");
      if (lengthInput) {
        lengthInput.value = pos.laenge || "";
      }
      const quantityInput = row.querySelector(".profile-anzahl");
      if (quantityInput && pos.anzahl !== undefined) {
        quantityInput.value = pos.anzahl;
        updateQuantityInputMode(row);
      }
    });
  }
});
